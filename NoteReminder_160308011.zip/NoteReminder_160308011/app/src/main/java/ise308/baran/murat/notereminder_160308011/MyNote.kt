package ise308.baran.murat.notereminder_160308011

import org.json.JSONObject

class MyNote {   // my Note Class
    var title: String? = null
    var description: String? = null
    var important: Boolean = false
    var todo: Boolean = false
    var idea: Boolean = false          // these are status of my note



    private val JSON_TITLE = "title"
    private val JSON_DESCRIPTION = "description"
    private val JSON_IMPORTANT = "important"
    private val JSON_TODO = "todo"
    private val JSON_IDEA = "idea"


    constructor(jObj: JSONObject) {       //    my Constructor

        title = jObj.getString(JSON_TITLE)
        description = jObj.getString(JSON_DESCRIPTION)
        important = jObj.getBoolean(JSON_IMPORTANT)
        todo = jObj.getBoolean(JSON_TODO)
        idea = jObj.getBoolean(JSON_IDEA)

    }


    constructor() {                     // my empty constructor

    }


    fun convertItJSON(): JSONObject {

        val jObj = JSONObject()   // JsonObject

        jObj.put(JSON_TITLE, title)
        jObj.put(JSON_DESCRIPTION, description)
        jObj.put(JSON_IDEA, idea)
        jObj.put(JSON_TODO, todo)
        jObj.put(JSON_IMPORTANT, important)

        return jObj
    }

}