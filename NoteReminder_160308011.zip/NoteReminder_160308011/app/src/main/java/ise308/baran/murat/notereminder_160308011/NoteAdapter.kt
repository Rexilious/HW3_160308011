package ise308.baran.murat.notereminder_160308011

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class NoteAdapter(
    private val mainActivity: MainActivity,
    private val noteList: List<MyNote>) : RecyclerView.Adapter<NoteAdapter.ListItemHolder>(){

    override fun getItemCount(): Int {   // I overrided getItemCount function
        if (noteList != null) {
            return noteList.size
        }
        // error
        return -1
    }
    override fun onCreateViewHolder(     // I overrided onCreateViewHolder function
        parent: ViewGroup, viewType: Int): ListItemHolder {

        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item, parent, false)

        return ListItemHolder(itemView)
    }


    override fun onBindViewHolder(
        holder: ListItemHolder, position: Int) {   // I overrided onBindViewHolder function

        val note = noteList!![position]


        holder.title.text = note.title // mTitle.text = note.title


        // display the first 10 characters of the original note
        if (note.description!!.length > 10){
        holder.description.text =  //mDescription.text =
            note.description!!.substring(0, 10)
        }else{
            holder.description.text =
                note.description!!
        }

        // Status of the note
        when {
            note.idea -> holder.status.text =
                mainActivity.resources.getString(R.string.idea_text)

            note.important -> holder.status.text =
                mainActivity.resources.getString(R.string.important_text)


            note.todo -> holder.status.text =
                mainActivity.resources.getString(R.string.todo_text)
        }

    }

    inner class ListItemHolder(view: View) :
        RecyclerView.ViewHolder(view),
        View.OnClickListener {

        internal var title = view.findViewById<View>(
            R.id.Title) as TextView

        internal var description = view.findViewById<View>(
            R.id.Description) as TextView

        internal var status = view.findViewById<View>(
            R.id.ViewStatus) as TextView

        init {
            view.isClickable = true
            view.setOnClickListener(this)

        }


        override fun onClick(view: View) {   // I overrided onClick function
            mainActivity.displayNote(adapterPosition)
        }

    }
}