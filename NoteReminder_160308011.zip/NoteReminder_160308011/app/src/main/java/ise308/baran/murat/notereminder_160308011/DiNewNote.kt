package ise308.baran.murat.notereminder_160308011

import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import android.widget.CheckBox
import android.widget.EditText


class DiNewNote : DialogFragment() {   // Dialog new note

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {  // I overrided onCreateDialog function


        val builder = AlertDialog.Builder(requireActivity())

        val inflater = requireActivity().layoutInflater

        val dialogViewer = inflater.inflate(R.layout.dialog_new_note, null)

        val editTitle = dialogViewer.findViewById(R.id.editTitle) as EditText

        val editDescr = dialogViewer.findViewById(R.id.editDescription) as EditText   // to edit Description

        val checkBoxImportant = dialogViewer.findViewById(R.id.checkBoxImportant) as CheckBox

        val checkBoxIdea = dialogViewer.findViewById(R.id.checkBoxIdea) as CheckBox

        val checkBoxTodo = dialogViewer.findViewById(R.id.checkBoxTodo) as CheckBox

        val buttonOK = dialogViewer.findViewById(R.id.buttonBack) as Button

        val buttonCancel = dialogViewer.findViewById(R.id.btnCancel) as Button

        builder.setView(dialogViewer).setMessage("Create a New Note!")

        // Handle the cancel button
        buttonCancel.setOnClickListener {
            dismiss()
        }

        buttonOK.setOnClickListener {
            // Create a new note
            val newNote = MyNote()

            // Set its properties to match the
            // user's entries on the form
            newNote.title = editTitle.text.toString()

            newNote.description = editDescr.text.toString()

            newNote.idea = checkBoxIdea.isChecked
            newNote.todo = checkBoxTodo.isChecked
            newNote.important = checkBoxImportant.isChecked

            // Get a reference to MainActivity
            val callingActivity = activity as MainActivity?

            // Pass newNote back to MainActivity
            callingActivity!!.createNote(newNote)

            // Quit the dialog
            dismiss()
        }

        return builder.create()


    }
}
