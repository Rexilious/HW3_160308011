package ise308.baran.murat.notereminder_160308011

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.view.View

import kotlinx.android.synthetic.main.activity_main.*
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.DefaultItemAnimator


class MainActivity : AppCompatActivity() {


    private var mSerializer: JSONSerializer? = null
    private var noteList: ArrayList<MyNote>? = null

    private var recyclerView: RecyclerView? = null
    private var adapter: NoteAdapter? = null
    private var showDividers: Boolean = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)

        fab.setOnClickListener { view ->
            val dialog = DiNewNote()
            dialog.show(supportFragmentManager, "")
        }

        mSerializer = JSONSerializer("NoteReminder_160308011.json",
            applicationContext)

        try {
            noteList = mSerializer!!.loadNote()
        } catch (e: Exception) {
            noteList = ArrayList()
            Log.e("Error loading notes: ", "", e)
        }

        recyclerView =
            findViewById<View>(R.id.recyclerView) as RecyclerView

        adapter = NoteAdapter(this, this.noteList!!)
        val layoutManager = LinearLayoutManager(applicationContext)

        recyclerView!!.layoutManager = layoutManager
        recyclerView!!.itemAnimator = DefaultItemAnimator()




        recyclerView!!.adapter = adapter  // for setting the adapter
    }

    fun createNote(n: MyNote) {   // for creating new Note

        noteList!!.add(n)
        adapter!!.notifyDataSetChanged()

    }
    private fun saveNotes() {
        try {
            mSerializer!!.saveNotes(this.noteList!!)

        } catch (e: Exception) {
            Log.e("Error while saving note", "", e)
        }
    }

    fun displayNote(noteToShow: Int) {
        val dialog = DiShowNote()
        dialog.sendNoteSelected(noteList!![noteToShow])
        dialog.show(supportFragmentManager, "")
    }




    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        return when (item.itemId) {
            R.id.action_settings -> {
                val intent = Intent(this,
                    Settings::class.java)

                startActivity(intent)
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onResume() {
        super.onResume()

        val prefs =
                getSharedPreferences(
                        "Note Reminder",
                        MODE_PRIVATE
                )

        showDividers = prefs.getBoolean(
                "dividers", true)

                                // Add a neat dividing line between list items
        if (showDividers)
            recyclerView!!.addItemDecoration(
                    DividerItemDecoration(
                            this, LinearLayoutManager.VERTICAL))
        else {
                                        // check there are some dividers or the app will crash
            if (recyclerView!!.itemDecorationCount > 0)
                recyclerView!!.removeItemDecorationAt(0)
        }

    }


    override fun onPause() {
        super.onPause()

        saveNotes()
    }



}