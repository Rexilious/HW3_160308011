package ise308.baran.murat.notereminder_160308011

import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import android.widget.TextView
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AlertDialog

class DiShowNote : DialogFragment() { // Dialog show note

    private var note: MyNote? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog { // I overrided onCreateDialog function


        val builder = AlertDialog.Builder(this.requireActivity())

        val inflater = requireActivity().layoutInflater

        val dialogViewer = inflater.inflate(R.layout.dialog_show_note, null)

        val textVTitle = dialogViewer.findViewById(R.id.txtTitle) as TextView

        val textVDescription = dialogViewer.findViewById(R.id.txtDescription) as TextView

        textVTitle.text = note!!.title
        textVDescription.text = note!!.description

        val textVImportant = dialogViewer.findViewById(R.id.textViewImportant) as TextView

        val textVTodo = dialogViewer.findViewById(R.id.textViewTodo) as TextView

        val textVIdea = dialogViewer.findViewById(R.id.textViewIdea) as TextView

        if (!note!!.important){
            textVImportant.visibility = View.GONE
        }

        if (!note!!.todo){
            textVTodo.visibility = View.GONE
        }

        if (!note!!.idea){
            textVIdea.visibility = View.GONE
        }

        val btnOK = dialogViewer.findViewById(R.id.buttonBack) as Button

        builder.setView(dialogViewer).setMessage("Your Note")

        btnOK.setOnClickListener({
            dismiss()
        })

        return builder.create()


    }


    // Receives a note from the "MainActivity" class
    fun sendNoteSelected(noteSelected: MyNote) {
        note = noteSelected
    }

}
